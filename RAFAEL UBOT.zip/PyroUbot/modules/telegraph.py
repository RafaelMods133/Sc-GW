__MODULE__ = "ᴛᴇʟᴇɢʀᴀᴘʜ"
__HELP__ = """
<blockquote><b>Bantuan untuk telegraph

perintah : <code>{0}tg</code> [reply media/text]
    mengapload media/text ke telegra.ph</b></blockquote>
"""
